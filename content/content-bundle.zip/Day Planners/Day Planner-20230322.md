## Day Planner
- [ ] [TF-4913](https://hashicorp.atlassian.net/browse/TF-4913) 
	- [ ] Finish up the following commands
		- [x] `rotate-encryption-password`
		- [x] `app-upgrade`
		- [x] `app-config `
		- [x] `license-info`
		- [x] `list-nodes`
		- [ ] `support-bundle`
		- [ ] `node-drain `