---
tags: daily-planner-20230421
---

## HashiCorp

- [ ] Create the nightly docs
	- [ ] Add them to confluence
- [ ] Clean up the [nightly build](https://github.com/hashicorp/ptfe-replicated/actions/runs/4750690775/jobs/8452679675)
	- [ ] Clear the [Jira ticket](https://hashicorp.atlassian.net/browse/TF-5832?atlOrigin=eyJpIjoiMjY5M2NiZTRlMThkNGQ0Y2IzZDhmMDZmMzUxNjE0MTEiLCJwIjoiaiJ9)
	- [ ] Announce in team channel that the nightly builds are stable
- [ ] In [Communication Tools](https://hashicorp.atlassian.net/wiki/spaces/IPL/pages/424804602/TFE+Bridge#Communication-Tools) section of the [TFE Bridge](https://hashicorp.atlassian.net/wiki/spaces/IPL/pages/424804602/TFE+Bridge) doc, change the Asana related items to Jira board
	- [ ] Include the on-call Jira board as well 
- [ ] Add Matt's [Terraform videos](https://courses.ardanlabs.com/courses/take/mutable-immutable-terraform-webinar/texts/44225849-our-services) to the [Product](https://hashicorp.atlassian.net/wiki/spaces/IPL/pages/424804602/TFE+Bridge#Product) section of the TFE Bridge guide.
	- [ ] Add a instruction bit to the list that points them to do the following
		- [ ] Log into 1Password
		- [ ] Search for the Ardan Labs Sign in/team specific
		- [ ] Choose your team login
		- [ ] Navigate and sign into [Ardan Labs](https://courses.ardanlabs.com/users/sign_in)
		- [ ] Search for our very own Matthew Sanabria's Terraform course
- [x] Do a work log doc on [TF-5832](https://hashicorp.atlassian.net/jira/software/c/projects/TF/issues/TF-5832?jql=project%20%3D%20%22TF%22%20AND%20assignee%20%3D%20currentUser()%20ORDER%20BY%20created%20DESC)
- [x] Get [TF-5320](https://hashicorp.atlassian.net/browse/TF-5320) ready for review
- [ ] Take over from Theo [TF-5322](https://hashicorp.atlassian.net/browse/TF-5322)
- [ ] Complete the expectation of a Lead Software engineer doc
	- [ ] Share to Chris when done.

## Personal

- [ ] Call Juan back
- [ ] Watch the [VIM in Visual Studio Code](https://www.youtube.com/watch?v=IMuFW9as-Dc) video
- [x] Clean up your file system on mac -- ain't using it? DELETE THAT 💩
- [ ] Watch the code navigation video on [YouTube](https://www.youtube.com/watch?v=_4rSbklsVkk)

## MentorCruise

- [ ] Systems Design: Twitter
	- [ ] Send to Matt when done
- [ ] Learning curriculum plan
	- [ ] Send to Matt when done

## Learning

- [ ] Bootcamp 💩
	- [ ] [Scaler](https://www.scaler.com/academy/mentee-dashboard/todos)
		- [ ] Create a doc in Obsidian for course
		- [ ] Intermediate DSA: Bit Manipulations
		- [ ] Intermediate DSA: Sorting
	- [ ] [Bloom Institute of Technology](https://www.bloomtech.com/)
		- [ ] Create a doc in Obsidian for course
		- [ ] Module 1
		- [ ] Module 2
		- [ ] Module 3
		- [ ] Module 4
		- [ ] Module 5
- [ ] Do the integration test with [Golang testing example](https://medium.com/@dilshataliev/integration-tests-with-golang-test-containers-and-postgres-abb49e8096c5)
