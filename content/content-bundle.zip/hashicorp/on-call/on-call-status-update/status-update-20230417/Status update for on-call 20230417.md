
## [support-terraform](https://hashicorp.slack.com/archives/C7HG09LBV) requests

- Issue: [TFE AA PostgreSQL Clustering](https://hashicorp.slack.com/archives/C7HG09LBV/p1681890305077039)
- Status: Closed
- Response to Issue: We do not support clustering for PostgreSQL because the connection string to connect to a cluster is different - you pass in multiple hosts. Neither replicated nor our application supports that type of connection string.
----------
- Issue: [Upgrade PostgreSQL on TFE](https://hashicorp.slack.com/archives/C7HG09LBV/p1680632986345159)
- Status: Closed
- Response to Issue: In Replicated this remains an issue but Matthew solves in a [PR](https://github.com/hashicorp/terraform-enterprise/pull/182)
----------
- Issue: [Structured run output does not work but console ui does](https://hashicorp.slack.com/archives/C7HG09LBV/p1681732361190649)
- Status: Open/Needs follow up
- Response to Issue: None as of 04/20/2023
------
- Issue: [Migrate to flexible server](https://hashicorp.slack.com/archives/C7HG09LBV/p1681824658595009)
- Status: No response as of 04/22/2023
- Response: Amy passed along the bit about how the `db` connection string is built.

## Nightly build update

As of 04/22/2023 the nightly builds as [🟢](https://share.getcloudapp.com/o0uYLNAG). There were some issues with Google Mounted Disk/Google Mounted disk consolidated tests that at first looked to be an issue with the schema be missing from TTW, which lead Matthew to dig further to then uncover that the subscribed account on both of the Google runs have the wrong subscribed account.

```bash
# gcloud auth list
						Credentialed Accounts
ACTIVE  ACCOUNT
*       logging-ptfe-replicated-ci@hc-50fbe27799384c96925f18084d7.iam.gserviceaccount.com
```

```bash
Apr 22 00:32:29 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script:
Apr 22 00:32:29 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script: To continue the installation, visit the following URL in your browser:
Apr 22 00:32:29 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script:
Apr 22 00:32:29 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script:   http://10.0.0.2:8800
Apr 22 00:32:29 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script:
Apr 22 00:32:29 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script: [Terraform Enterprise] Registering gcloud as a Docker credential helper
Apr 22 00:32:30 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script: Adding credentials for: us-west1-docker.pkg.dev
Apr 22 00:32:31 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script: Docker configuration file updated.
Apr 22 00:32:31 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script: [Terraform Enterprise] Pulling custom worker image 'us-west1-docker.pkg.dev/hc-50fbe27799384c96925f18084d7/terraform-build-worker/rhel-7.9:latest'
Apr 22 00:32:33 ses-aardvark-tfe-bjvn google_metadata_script_runner[1669]: startup-script: Error response from daemon: Head "https://us-west1-docker.pkg.dev/v2/hc-50fbe27799384c96925f18084d7/terraform-build-worker/rhel-7.9/manifests/latest": denied: Permission "artifactregistry.repositories.downloadArtifacts" denied on resource "projects/hc-50fbe27799384c96925f18084d7/locations/us-west1/repositories/terraform-build-worker" (or it may not exist)
```

It is also likely that `google-external-rhel8-worker-consolidated-services` test isn't actually using the RHEL image as a worker.

For more information Matthew would be the person to reach out to because I was just a passenger at that point.


  
   
  
