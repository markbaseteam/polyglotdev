The purpose of this document is to outline some of the tips and tricks for dealing with the nightly builds.

## The `Error` is **not** where you think it is

For whatever reason the GitHub Action UI will when you enter a failing job will jump you to the end of the output. That looks like this:

![[github-actions-failed-test-ui-interaction.gif]]

👆🏾 That is **not** the error that we want. What you will need to do is, scroll up in the UI until you the section after Terraform is creating resources and look for the errors there.

The error will look something like this:

```shell
|
│ Error: Error creating service account key: googleapi: Error 400: Precondition check failed., failedPrecondition
│ 
│   with module.tfe.module.service_accounts.google_service_account_key.key,
│   on ../../modules/service_accounts/main.tf line 25, in resource "google_service_account_key" "key":
│   25: resource "google_service_account_key" "key" ***
│ 
|
```

Without going too far down the rabbit hole, I can tell you that 👆🏾 is a transient error.

## Accessing Cloud Resources

All requests for accounts below should be made thru [doormat](https://doormat.hashicorp.services/). Once you are auth'd into doormat, select cloud access from the top nav, choose the cloud service you want access to and request access by completing the form. Do this for all three cloud services.

### AWS

To access AWS resources for the builds, you can navigate to Doormat and click AWS Accounts tab then under account name find [tfe_team_dev](https://doormat.hashicorp.services/console/awssg-hc1-tfe_team_dev-developer-278647779083) account and click the console icon in that row to sign into the AWS console.

> 🧠 We run our resources in US-West 2 so make sure that after you get logged in to AWS that you go to top and switch you region to **US-West 2**

### GCP

[tf-onprem-dev](https://doormat.hashicorp.services/accounts/hc-1eee1e0fde6f4d6cb76f7157200) is the project that you need access to for the nightly on GCP

### Azure

[ptfe-replicated-testing-ci]() is the subscription that we need for Azure.

> should you find resource groups on the ptfe-replicated-testing-ci that follow this pattern `xxxx-rg` its a safe bet that should delete them.