Chris sent a passive aggressive message about my [work-log](https://domslinks.com/43LLuAS) sheet and how he "appreciated" it and then proceeded to bitch about the nightly builds. The nightly builds are kind of a bitch because I have not had any training on them. If we are being honest, I did not even know where they were!

The purpose of this doc is to outline what I have tried, as well as any nuggets of learning.

## What do you know?

1. The [builds](https://github.com/hashicorp/ptfe-replicated/actions/runs/4739709053) are failing. 
2. Seemingly each run of the failing actions produce different errors each time.

## What do you not know/Questions

> 🚨 avoid asking any existential bullshit

1. Someone setup the variables that are being used [here](https://github.com/hashicorp/ptfe-replicated/settings/secrets/actions), but how did they know what subscriptions needed to be used for each cloud?
	1. **Best guess**: I would expect that if I follow the path to the Terraform that is actually spinning up the resources that I can find all of the subscription information.
2. I got an error about too many IP addresses, how do I access the instance that is having the issue?
	1. **Best guess**: The only thing that I know to do is go to the Terraform code, figure out what workspace this is running in, download the state file and see if you can't reason about what is what in terms of getting the instance group, etc etc
3. For nightly builds what `SHA`'s should be used? They are different from the regular builds but which one's need to be used and how do you find them?

## Errors

### `azurerm-external-consolidated-services`

```bash
Error: Process completed with exit code 1.
```

#### Diagnosis 🩺

I think that this a red herring and a result of other tests failing.

-----

### `google-mounted-disk`

```bash
Error: Process completed with exit code 1.
```

#### Diagnosis 🩺

💩, I don't know what to think here? Why is the process existing like that?

----------

### `google-mounted-disk-consolidated-services`

```bash
Error: Process completed with exit code 1.
```

#### Diagnosis 🩺

I find it odd that all three of the first ones all have the same error message.

--------

### `google-external-rhel8-worker`

```bash
│ Error: Error creating service account key: googleapi: Error 400: Precondition check failed., failedPrecondition
│ 
│   with module.tfe.module.service_accounts.google_service_account_key.key,
│   on ../../modules/service_accounts/main.tf line 25, in resource "google_service_account_key" "key":
│   25: resource "google_service_account_key" "key" ***
│ 
╵
```

#### Diagnosis 🩺

Yay, a new error! Well this one appears to not have been able to create the service account key and has something to do with 👇🏾`google_service_account_key`

-----------

### `google-external-rhel8-worker-consolidated-services`

```bash
Error: Process completed with exit code 1.
```

#### Diagnosis 🩺

At this point, we have 4 of the same error where it just chucks up the deuces on me ✌️ and quits. Is there any correlation with the as of yet, four same errors?

-----------

### `aws-external-vault`

```bash
Error: Process completed with exit code 1.
```

#### Diagnosis 🩺

Like Cardi B, I think that is suspicious and weird because now that is 5 of the same error message.

------------

To make a long story short, the other jobs have mixture of our repeated error message and then some of the jobs initialize Terraform and the proceed forward with no output errors.

There is one case where I need to go a prune some of the instances that are running because Terraform giving me the error `you have too many mother fucking IP's in the region. DELETE YO SHIT` but then my next question is, why is it not tearing down the instance after the job is good to go? Does it just leave the instance up and dirty after the job fails? I actually don't think that its that but what else could it fucking be? 

![jordan shrug](https://media.giphy.com/media/l3q2JCu9lep6dAmyY/giphy.gif)

## What have you tried

1. Kicking the jobs off again
2. Kicking just the failed jobs
3. Check the SHA's and see if they are correct
   
My assumption is that I am going to have to deal first with the low hanging fruit problems of the, "too many IP's" and then deal with the others.