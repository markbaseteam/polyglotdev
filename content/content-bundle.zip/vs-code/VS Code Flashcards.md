---
tags: flashcards
---

quick open:::`⌘ + p`
<!--SR:!2023-04-26,4,270-->
Quick open multiple:::`⌘+p` and then select file with arrow keys and then use the right arrow
<!--SR:!2023-04-23,1,230-->
Open to the side:::quick-edit command and the `control+enter`