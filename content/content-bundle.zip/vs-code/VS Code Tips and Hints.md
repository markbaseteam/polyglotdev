---
tags: vs-code
---

## Code Navigation

- Quick Open: `⌘+p`
- Quick open multiple: `⌘+p` and then select file with arrow keys and then use the right arrow
- Open to the side: quick-edit command and the `control+enter`
- Go Back and Forward
	- Back: `control + -`
	- Forward: Back: `control + shift + -`
	- Go back to last edit `⌘ K` `⌘ Q`
- Go to Bracket: `shift + ⌘ + \`
- Sort by Symbol: `⌘ + shift +  o`
- Sort by Symbol & To the side: `⌘ + shift + o` and then next to the `@` add a colon like this `@:` then to open to the side just do `control + enter`
- Quick open with Goto symbol: `⌘ + p` to quick open and then you need to type the file name and select the file you are wanting with the arrow keys Finally you can do `@:name of symbol`
- Goto Definition: `f12`
- Peek Definition: `opt + f12`
- Goto References: `shift + f12`
- Call Hierarchy: `shift + option + h`
- Goto Problem: `f8`



