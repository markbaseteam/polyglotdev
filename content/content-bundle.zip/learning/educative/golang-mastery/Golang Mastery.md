---
tags: golang learning
---

[Course Link](https://www.educative.io/)

## Arrays

fixed-length sequence of data elements with homogeneous data(all the same type)

> 🧠 max length on an array in **2** gigabytes.

```go
var identifier [len]type
```

