[Course Link](https://quii.gitbook.io/learn-go-with-tests/)

## Test Writing Rules

- name the file like this `xxx_test.go`
	- keep the file close to the the functions that its testing
- The test function must start with the word `Test`
	- It takes one argument `t *testing.T`

### `t.Errorf`

We call the `Errorf` method on our `t` which will print out a message and fail the test. The `f` stands for **format** which allows us to build a string with values inserted into the placeholder values `%q`

> You can learn more about placeholder strings in the [fmt go doc](https://golang.org/pkg/fmt/#hdr-Printing)

## Go doc

A feature of Go is the documentation. You launch the docs with `godoc -http :8000`. For your local system you can just use `godoc` which will run the server on port 6060.

## Refactored assertion

```go
func assertCorrectMessage(t *testing.T, got, want string) {
	t.Helper()
	if got != want {
		t.Errorf("got %q want %q", got, want)
	}
}
```

👆🏾 we have refactored the assertion, or the the factual statement as in, "if got is not equal to want do a thing" into its own function thereby cleaning up the test.

## Interfaces

In the example above we use a `t *testing.T` and `t *testing.TB`.

> 🧠 it is a good idea to accept `t *testing.TB` in your tests as both the `t *testing.T` and `t *testing.B` satisfy an interface `t *testingTB`. The `T` is for **testing** and the `B` is for **benchmark**

`t.helper()` is needed to tell the test suite that this method is a helper. By doing this when it fails the line number reported will be in our _function call_ rather than inside our test helper. This will help other developers track down problems easier. If you still don't understand, comment it out, make a test fail and observe the test output. Comments in Go are a great way to add additional information to your code, or in this case, a quick way to tell the compiler to ignore a line. You can comment out the `t.Helper()` code by adding two forward slashes `//` at the beginning of the line. You should see that line turn grey or change to another color than the rest of your code to indicate it's now commented out.

In Go, an interface is a set of method signatures. When a type implements an interface, it means that it provides implementation for all the methods in the interface.

```go
// Define an interface named Shape
type Shape interface {
    Area() float64
}

// Define a struct named Rectangle with length and width fields
type Rectangle struct {
    length float64
    width  float64
}

// Implement the Area method of the Shape interface for Rectangle
func (r Rectangle) Area() float64 {
    return r.length * r.width
}
```

In this example, we define an interface named `Shape` with a single method `Area()`. Then, we define a struct named `Rectangle` with two fields `length` and `width`. Finally, we implement the `Area()` method of the `Shape` interface for the `Rectangle` struct.

By implementing the `Area()` method for the `Rectangle` struct, we say that the `Rectangle` type satisfies the `Shape` interface. This means that we can use any value of the `Rectangle` type anywhere that a value of the `Shape` interface is expected. For example:

```go
func printArea(s Shape) {
    fmt.Printf("Area: %f\n", s.Area())
}

r := Rectangle{length: 5, width: 10}
printArea(r) // Output: Area: 50.000000

```
