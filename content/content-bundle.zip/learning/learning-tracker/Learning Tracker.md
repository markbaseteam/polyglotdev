| Course         | Platform                               | Hours Spent | Link to Certificate | Link to Repo | Link to Notes |
| -------------- | -------------------------------------- | ----------- | ------------------- | ------------------- | --------|
| Golang Mastery | [Educative](https://www.educative.io/) | 47          | [link]()            | [golang-mastery-educative](https://github.com/polyglotdev) | [Golang Mastery Notes](https://polyglotdev.markbase.xyz)| 

