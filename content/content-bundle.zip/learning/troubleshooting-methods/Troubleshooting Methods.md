One of the things that separates junior engineers from senior engineers is the ability to troubleshoot something effectively. What I mean by "effectively" is that even when the senior engineer does not know exactly what is wrong, they are still able to use a method to get to where they are trying to go. Guessing is what junior engineers do and this is not a good use of your time.

Matthew is one of the best engineers that I know and he has a clear method that seems pretty straight forward so what I want to do is outline what he does so I can model my own method from his.

## Sudomateo Problem Solving Method

1. Information gathering: 
	1. What are our errors?
	2. What can be dismissed as transient error
	3. Are there stop the world errors