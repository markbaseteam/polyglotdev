[Course link](https://www.udemy.com/course/dart-and-flutter-the-complete-developers-guide/learn/lecture/10961156#overview)
[Finished Code](https://github.com/StephenGrider/FlutterCasts/)

## Dart

> 🧠 `main` is the entry point to the project and must be present in every dart program

```dart
void main() {
  var n = myName('Elijah');
  print(n);
}

String myName(name) {
  return 'Hello, $name!';
}
```

## Types in Dart

- every value has a type
- every variable has a type it can reference
- once a variable has a type associated the variables' type can not change
- We don't always want to annotate types, It can be inferred by the compiler at times.

| Type      | Exampe                    |
| --------- | ------------------------- |
| `String`  | `'hello'`                     | 
| `int`     | 4                           |
| `double`  | 4.65                        |
| `dynamic` | `'hey'`, `44`, `4`, `4.0`           |

## Why use types at all?

- Performance could be improved
- Easier to work on large projects
- Less of a need to write unit tests (yeah 👈🏾 is bullshit)
- 'Automatically' find simple errors

## String Interpolation

When you are inside of a function you can the same syntax as the first example above 👆🏾. If you are not in function then you can not use that `$varName` syntax

## Object Orientated Program

OOP is a paradigm that allows the engineer thru the use of objects to create concrete things from every day life.

- Class: Set of blueprints for objects
- Object/Instance: A occurrence of the object

### Classes

```dart
// Person defines what a person is
class Person {
  String firstName;
  String lastName;
  int age;
  Person(this.firstName, this.lastName, this.age);

  printName() {
    print('$firstName $lastName');
  }
}
```

> 💡 `void` means we are not returning anything from the function

