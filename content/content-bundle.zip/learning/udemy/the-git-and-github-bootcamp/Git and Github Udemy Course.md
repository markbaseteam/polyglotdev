`ris:Github` [course link](https://www.udemy.com/course/git-and-github-bootcamp/learn) 
## [[Rebase]]
There are two main ways to use the `git rebase` command:
1. Alternative to merging
2. Clean up tool
## [[Rebase Problems]]
Lots of changes of `main` create the need to `git merge` which creates new commits.

> 💡 Fast Forward commits can only happen when you have new commits on **<mark style="background: #ABF7F7A6;">your branch</mark>** and `main` <mark style="background: #FFF3A3A6;">has not had any at the point of your merge</mark>.
## [[Rebase Workflow]]
1. `git checkout` your branch
2. `git rebase main`
## [[Golden Rule of Rebase]]
> 💡 **NEVER REBASE COMMITS THAT HAVE BEEN SHARED WITH OTHERS.**

So we `rebase` <mark style="background: #FFF3A3A6;">onto</mark> <mark style="background: #FFF3A3A6;">the branch that we currently are on</mark>.





