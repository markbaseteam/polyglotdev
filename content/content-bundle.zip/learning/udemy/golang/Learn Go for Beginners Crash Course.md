```go
package main

import "fmt"

func main() {
	fmt.Println("Hello, 🌎!")
}
```

## Section 4: Types Expressions and Composition




