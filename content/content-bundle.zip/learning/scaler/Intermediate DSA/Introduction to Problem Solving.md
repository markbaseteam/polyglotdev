## [[Instructor Information]]
### Prakhar Agrawal
- [Youtube]([https://www.youtube.com/user/prakhar3agrwal](https://www.youtube.com/user/prakhar3agrwal))
- [LinkedIn]([https://www.linkedin.com/in/prakhar3agrwal/](https://www.linkedin.com/in/prakhar3agrwal/))
## [[Scaler Curriculum]]
- 2 months → Intermediate Problem Solving
- 4 months → Advanced Problem Solving
- Class 3 days a week
	- Wednesday
	- Friday
	- Saturday
**Pseudo Code for core logic**
## [[Ways to succeed in course]]
1. Revisit of lectures
2. Assignments matter!
3. Homework need to be done on time
## [[Systems Design]]
Teaches you how to design systems at scale. It also teaches how you design the code. So this part is going to have high-level and low-level design aspects.
## Final Project
- Frontend
	- [React](https://react.dev/)
- Backend
	- [Java](https://www.java.com/en/)
	- [SpringBoot](https://spring.io/)

## Count of factors
A factor is when any number can be divided equally into `n`.
$$
n \mod i == 0
$$

Then `i` is a factor of `n`. Below is an implementation of this algorithm in Go:

```go
package main

import "fmt"

func main() {
	fmt.Println("Factors of 12: ", Factors(12))
}

// Factors takes in a number and returns a slice of all the factors of that number.
func Factors(n int) []int {
	var factors []int
	for i := 1; i <= n; i++ {
		if n%i == 0 {
			factors = append(factors, i)
		}
	}
	return factors
}
```
> Stopped video at 0936 - 32:10 into [video](https://www.scaler.com/academy/mentee-dashboard/class/69680/session?joinSession=1)