[NBA API](https://rapidapi.com/api-sports/api/api-nba)
[NBA API Documentation](https://api-sports.io/documentation/nba/v2)

## Create a `client`

Instead of jamming everything into `main` we can create a client.